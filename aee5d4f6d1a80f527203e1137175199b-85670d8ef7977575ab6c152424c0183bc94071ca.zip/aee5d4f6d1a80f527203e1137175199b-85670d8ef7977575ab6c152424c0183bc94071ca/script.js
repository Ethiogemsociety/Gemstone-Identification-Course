document.addEventListener("DOMContentLoaded", function () {
  const adminEmail = "kidusdawit0000an@gmail.com";
  const adminPassword = "Kidus2Kidus2Kidus77an@";
  const adminLink = document.getElementById("admin-link");
  const adminLogin = document.getElementById("admin-login");
  const adminLoginBtn = document.getElementById("admin-login-btn");
  const uploadOptions = document.getElementById("upload-options");
  const adminFileInput = document.getElementById("admin-file");
  const adminUploadBtn = document.getElementById("admin-upload-btn");

  // Show the admin login form when the admin link is clicked
  adminLink.addEventListener("click", function (event) {
    event.preventDefault();
    adminLogin.style.display = "block";
    adminLogin.scrollIntoView({ behavior: "smooth" });
  });

  // Handle admin login
  adminLoginBtn.addEventListener("click", function () {
    const enteredEmail = document.getElementById("admin-email").value;
    const enteredPassword = document.getElementById("admin-password").value;

    if (enteredEmail === adminEmail && enteredPassword === adminPassword) {
      alert("Admin login successful!");
      adminLogin.style.display = "none";
      uploadOptions.style.display = "block";
      adminUploadBtn.disabled = false;
    } else {
      alert("Invalid email or password.");
    }
  });

  // Handle file upload
  adminUploadBtn.addEventListener("click", function () {
    if (adminFileInput.files.length > 0) {
      alert("File uploaded successfully!");
      adminFileInput.value = ""; // Clear the file input after upload
    } else {
      alert("Please select a file to upload.");
    }
  });

  // Protecting Buttons from Editing
  document.querySelectorAll("button").forEach((button) => {
    button.setAttribute("contenteditable", false);
  });

  // Payment Proof Upload
  document
    .getElementById("proof-upload-form")
    .addEventListener("submit", function (event) {
      event.preventDefault();
      alert(
        "Payment proof uploaded successfully. We will verify and get back to you."
      );
      this.reset();
    });

  // Form Submission for Contact
  document
    .getElementById("contact-form")
    .addEventListener("submit", function (event) {
      event.preventDefault();
      const form = this;
      const formData = new FormData(form);
      const mailtoLink = `mailto:${adminEmail}?subject=Contact%20Form%20Submission&body=Name:%20${formData.get(
        "name"
      )}%0AEmail:%20${formData.get("email")}%0AMessage:%20${formData.get(
        "message"
      )}`;
      window.location.href = mailtoLink;
      form.reset();
    });

  const courses = [
    {
      title: "Introduction to Gemstones",
      description: "Learn the basics of gemstone identification and grading.",
      price: "5500 Birr / 50 USD"
    },
    {
      title: "Gemstone Formation",
      description: "Understand the natural processes that form gemstones.",
      price: "5500 Birr / 50 USD"
    },
    {
      title: "Gemstone Identification",
      description: "Master the techniques used to identify various gemstones.",
      price: "5500 Birr / 50 USD"
    },
    {
      title: "Gemstone Testing",
      description:
        "Learn how to test and verify the authenticity of gemstones.",
      price: "5500 Birr / 50 USD"
    }
  ];

  const courseList = document.querySelector(".course-list");

  courses.forEach((course) => {
    const courseElement = document.createElement("div");
    courseElement.classList.add("course");
    courseElement.innerHTML = `
            <h3>${course.title}</h3>
            <p>${course.description}</p>
            <p>Price: ${course.price}</p>
            <button>Enroll Now</button>
        `;
    courseElement
      .querySelector("button")
      .addEventListener("click", function () {
        if (confirm("Have you completed the payment?")) {
          alert("Thank you for enrolling! Please upload your payment proof.");
          document
            .getElementById("proof-upload-form")
            .scrollIntoView({ behavior: "smooth" });
        } else {
          alert("Please complete the payment before enrolling.");
        }
      });
    courseList.appendChild(courseElement);
  });
});
